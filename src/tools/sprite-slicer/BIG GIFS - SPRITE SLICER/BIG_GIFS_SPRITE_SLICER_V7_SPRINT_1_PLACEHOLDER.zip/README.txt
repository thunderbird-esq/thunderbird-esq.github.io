This ZIP will contain the updated HTML with:
- Grid Overlay Toggle
- Zoom and Pan Controls
- Snap-to-Grid in Manual Mode

Code will be generated and added once finalized in the next steps.